Description
===========

Package contains methods to work with files and directories.